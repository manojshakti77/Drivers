#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/proc_fs.h>
#include <linux/sched.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/slab.h>
#include <linux/mm.h>
#include <asm/highmem.h>
#include <asm/uaccess.h>

MODULE_LICENSE ("Dual BSD/GPL");

#define CTRL_REG_SIZE 1
#define STAT_REG_SIZE 1

int read_proc_speed(struct file *fp, char *buf, size_t count, loff_t *offp);
int write_proc_speed(struct file *fp, const char *buf, size_t count, loff_t *offp);

int read_proc_iotype(struct file *fp, char *buf, size_t count, loff_t *offp);
int write_proc_iotype(struct file *fp, const char *buf, size_t count, loff_t *offp);

static int myInit (void);
static void myExit (void);

static struct proc_dir_entry *proc_parent;

struct file_operations proc_fops_speed = {
		.read = read_proc_speed,
		.write = write_proc_speed,
};

struct file_operations proc_fops_iotype = {
		.read = read_proc_iotype,
		.write = write_proc_iotype,
};

long int *ctrl_reg;
long int *stat_reg;

long int speed_data;
long int iotype_data;
