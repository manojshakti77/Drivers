#include "vcommdev_stage3_header.h"

int read_proc_speed(struct file *fp, char *buf, size_t count, loff_t *offp)
{
	static int finished = 0;
	
	if (finished) {
		finished = 0;
		return 0;
	}
	
	finished = 1;

	sprintf(buf, "%ld\n", *ctrl_reg);

	return strlen(buf);
}

int write_proc_speed(struct file *fp, const char *buf, size_t count, loff_t *offp)
{
	#define PROC_BUFF_SIZE 30

	char proc_buff[PROC_BUFF_SIZE];
	static long int temp = 0;
 
	if (copy_from_user(proc_buff, buf, count)) {
		return -EFAULT;
	}

	temp = simple_strtoul(proc_buff, NULL, 10);
	if (temp > 65536) {
		temp = 0;
		return -EFAULT;
	}

	*ctrl_reg = temp;
	temp = 0;

	return count;
}

int read_proc_iotype(struct file *fp, char *buf, size_t count, loff_t *offp)
{
	static int finished = 0;
	
	if (finished) {
		finished = 0;
		return 0;
	}
	
	finished = 1;

	if (*stat_reg == 0)	
		sprintf(buf, "%s\n", "buffered I/O");
	else if (*stat_reg == 1)
		sprintf(buf, "%s\n", "Unbuffered I/O");
	else 
		sprintf(buf, "%s\n", "Unknown I/O type");
	

	return strlen(buf);
}

int write_proc_iotype(struct file *fp, const char *buf, size_t count, loff_t *offp)
{
	#define PROC_BUFF_SIZE 30

	char proc_buff[PROC_BUFF_SIZE];
 
	if (copy_from_user(proc_buff, buf, count)) {
		return -EFAULT;
	}

	*stat_reg = simple_strtoul(proc_buff, NULL, 10);

	return count;
}

static int __init myInit(void)
{
	ctrl_reg = kmalloc(1, CTRL_REG_SIZE);
	if (ctrl_reg == NULL) {
		printk(KERN_ERR "Memory allocation failed for control register\n");
		return -1;
	}

	*ctrl_reg = 0;

	stat_reg = kmalloc(1, STAT_REG_SIZE);
	if (stat_reg == NULL) {
		printk(KERN_ERR "Memory allocation failed for status register\n");
		kfree(ctrl_reg);
		return -1;
	}

	*stat_reg = 0;

	proc_parent = proc_mkdir("vcommdev", NULL);
	if (!proc_parent) {
		printk(KERN_ERR "Error creating proc entry for vcommdev");
		return -ENOMEM;
	}

	proc_create("speed", 0666, proc_parent, &proc_fops_speed);
	proc_create("iotype", 0666, proc_parent, &proc_fops_iotype);

	return 0;
}

static void myExit (void)
{
	kfree(ctrl_reg);
	kfree(stat_reg);

	remove_proc_entry("speed", proc_parent);
	remove_proc_entry("vcommdev", NULL);

	return;
}

module_init(myInit);
module_exit(myExit);
