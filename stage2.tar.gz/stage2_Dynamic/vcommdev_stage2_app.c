#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>

int main()
{
	int fd = 0;
	int select = 0;
	int value = 0;
	
	fd = open("/dev/vcommdev",O_RDWR);

	if (fd < 0)
		perror("Unable to open the device\n");
	else 
		printf("File opened Successfully %d\n", fd);

	while (1) {	
		printf("Select one operation to perform\n\t1) Set control bit register\n"
		       "\t2) Read control bit register\n\t3) Set status register\n"
		       "\t4) Read status bit register\n\t5) Exit from loop\n");
		scanf("%d", &select);

		switch(select) {
			case 1	:	printf("Enter the baud rate you want to set\n");
						scanf("%d", &value);
						value = (value | 0x00030000);
						ioctl(fd, getpid(), value);
						break;
	
			case 2	:	value = 0x00010000;
						value = ioctl(fd, getpid(), value);
						printf("Baud rate = %d\n", value);
						break;

			case 3	:	printf("Select I/O type\n\t1) 0 - Buffered I/O\n\t"
							   "2) 1 - Unbuffered I/O\n");
					scanf("%d", &value);
					if (value == 2) {
						value = 1;
					} else {	
						value = 0;
					}
					value = (value | 0x00040000);
					ioctl(fd, getpid(), value);
					break;

			case 4	:	value = 0x00000000;
					value = ioctl(fd, getpid(), value);
					value ? printf("Unbuffered I/O\n") : printf("buffered I/O\n");
					break;

			case 5	:	goto terminate_loop; break;

			default	:	printf("Invalid option selected\n");
		}
	}

	terminate_loop:
		close(fd);

	return 0;	
}
