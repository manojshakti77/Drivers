#include "vcommdev_stage2_header.h"

int myOpen(struct inode *inode, struct file *filep)
{	
	ctrl_reg = kmalloc(1, CTRL_REG_SIZE);
	if (ctrl_reg == NULL) {
		printk(KERN_ERR "Memory allocation failed for control register\n");
		return -1;
	}

	stat_reg = kmalloc(1, STAT_REG_SIZE);
	if (stat_reg == NULL) {
		printk(KERN_ERR "Memory allocation failed for status register\n");
		kfree(ctrl_reg);
		return -1;
	}

	return 0;
}

long myIoctl(struct file *fp, unsigned int pid, long unsigned int value)
{
	int reg_check_flag = 0;
	int ctrl_check_flag = 0;
	int stat_check_flag = 0;

	reg_check_flag = (value & 0x00010000);
	if (reg_check_flag) {
		ctrl_check_flag = (value & 0x00020000);
		if (ctrl_check_flag) {
			*ctrl_reg = (value & 0x0000FFFF);
			return 0;
		} else {
			return *ctrl_reg;
		}
	} else {
		stat_check_flag = (value & 0x00040000);
		if (stat_check_flag) {
			*stat_reg = (value & 0x000000FF);
			return 0;
		} else {
			return *stat_reg;
		}
	}
	
	return (long)0;
}

int myRelease(struct inode *in, struct file *fp)
{
	kfree(ctrl_reg);
	kfree(stat_reg);

	return 0;
}

static int __init myInit(void)
{
	int ret	=	-ENODEV;
	int status;

	status = alloc_chrdev_region(&mydev, FIRST_MINOR, NR_DEVS, devname);

	if (status < 0)
	{
		printk(KERN_NOTICE "Device numbers allocation failed: %d\n",status);
		goto err;
	}

	my_cdev = cdev_alloc();

	if (my_cdev == NULL) {
		printk(KERN_ERR "cdev_alloc failed\n");
		goto err_cdev_alloc;
	}

	cdev_init(my_cdev, &fops);
	my_cdev->owner = THIS_MODULE;

	status = cdev_add(my_cdev, mydev, NR_DEVS);
	if (status) {
		printk(KERN_ERR "cdev_add failed\n");
		goto err_cdev_add;
	}

	mychar_class = class_create(THIS_MODULE, devname);
	if (IS_ERR(mychar_class)) {
		printk (KERN_ERR "class_create() failed\n");
		goto err_class_create;
	}

	mychar_device =	device_create(mychar_class, NULL, mydev, NULL, devname);
	if (IS_ERR(mychar_device)) {
		printk(KERN_ERR "device_create() failed\n");
		goto err_device_create;
	}

	return 0;

	err_device_create:
		class_destroy(mychar_class);

	err_class_create:
		cdev_del(my_cdev);

	err_cdev_add:
		kfree(my_cdev);

	err_cdev_alloc:
		unregister_chrdev_region(mydev, NR_DEVS);

	err:
		return ret;
}

static void myExit (void)
{
	device_destroy(mychar_class, mydev);
	class_destroy(mychar_class);
	cdev_del(my_cdev);
	unregister_chrdev_region(mydev, NR_DEVS);

	return;
}

module_init(myInit);
module_exit(myExit);
