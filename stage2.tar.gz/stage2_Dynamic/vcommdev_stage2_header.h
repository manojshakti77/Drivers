#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/slab.h>
#include <linux/mm.h>
#include <asm/highmem.h>
#include <asm/uaccess.h>

MODULE_LICENSE ("Dual BSD/GPL");

#define FIRST_MINOR	0
#define NR_DEVS 1
#define CTRL_REG_SIZE 1
#define STAT_REG_SIZE 1

int myOpen (struct inode *inode,struct file *filep);
int myRelease (struct inode *in,struct file *fp);
long myIoctl (struct file *, unsigned int, unsigned long);

static int myInit (void);
static void myExit (void);

struct file_operations fops = {
		.owner	=	THIS_MODULE,
		.open	=	myOpen,
		.unlocked_ioctl	=	myIoctl,
		.release	=	myRelease
};

char *devname = "vcommdev";
int majNo;
static dev_t mydev;
struct cdev *my_cdev;
long int *ctrl_reg;
long int *stat_reg;

static struct class *mychar_class;
static struct device *mychar_device;
